Hey there! I'm super excited to see what comes of these files :P
Okay, so these files span a couple genres of music, and I'm sorry I couldn't really find MIDI files of songs, per se, but those are easy enough to download.
9God, 808 Mob, Cobra and Drip are hard hip-hop with straightforward chord progressions with no frills for the most part. There are a few melodies without chords here or there, but those are few.
Eternity and Lofi are, well, lo-fi packs. Very experimental writing with unconventional cadences and resolution. Experimental stuff.
These MIDIs are a mix of bought as well as free downloads, and are completely royalty-free, so you don't have to worry about any of that stuff, either.
I have built up this collection over the course of a couple years, so there might be a slight shift in the way they actually sound due to how these genres have evolved.
Anyway, you take it from here, and all the best!

Best,
Mohit